export class LoginDTO {
    username: string;
    password: string;
}