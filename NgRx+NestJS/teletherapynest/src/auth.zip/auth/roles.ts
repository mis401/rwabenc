export enum Role {
    Patient = 'patient',
    Doctor = 'doctor',
    Head = 'head',
}